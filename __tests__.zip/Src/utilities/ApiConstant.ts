

export const base_url = 'https://jsonplaceholder.typicode.com';

export const TypiCodeListData = base_url + '/posts';



