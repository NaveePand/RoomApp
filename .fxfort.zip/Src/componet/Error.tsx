import React from 'react';
import { Text } from 'react-native';

const ErrorToast = () => {
  return <Text>Error Toast Component</Text>;
};

export { ErrorToast };
