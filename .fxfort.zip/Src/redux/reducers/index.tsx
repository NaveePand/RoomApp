import user from "./user/UserReducer";
// add multiple reducer in this method
const reducers = {
  user,
};

export default reducers;
